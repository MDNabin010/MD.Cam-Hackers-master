pkg update -y
pkg upgrade -y
apt-get install python3 -y
pkg install python -y
pkg install python2 -y
apt-get install git -y
pip3 install requests
